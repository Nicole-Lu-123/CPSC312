import System.IO
import Control.Monad
import Data.Bits
import Data.Char (ord, chr)
import Data.Map (Map)             -- This just imports the type name
import qualified Data.Map as M
import XorCipher
import Text.Read   (readMaybe)
import Data.Maybe   (fromJust)



main =
    do
    --putStr ("Hello! What do you want to do?"++"\n");
    content <- readFile "password.txt";
    let linesOfContent = lines content;
    let n = length(linesOfContent);
    loadedPasswords <- loadForLoop n linesOfContent loadFile;
    let password2 = M.lookup ("masterpassword", "masterpassword") loadedPasswords
    if (password2 == Nothing)
      then
        print ("something is wrong, you have no masterpassword ")
      else
        putStr ("plase enter your master password:"++"\n")
    answer <- getLineFixed    
    if (answer == decode (fromJust password2))
      then 
        ask loadedPasswords;
      else
        putStr("wrong master password!")
      

loadForLoop 0 linesOfContent map_data = return map_data;
loadForLoop n linesOfContent map_data = 
  do
    let oneLine = linesOfContent !! (n-1);
    let arrayOfString = words oneLine;
    let w = arrayOfString !! 0;
    let u = arrayOfString !! 1;
    let epString = arrayOfString !! 2;
    let numberOfPasswords = div (length(epString)-1) 4;
    passwordArray <- subForLoop numberOfPasswords epString [];
    --putStr $ show $ length passwordArray
    let tempMapData = M.insert (w, u) passwordArray map_data;
    let map_data = tempMapData;
    loadForLoop (n-1) linesOfContent map_data;

subForLoop 0 epString passwordArray2 = return passwordArray2;   
subForLoop n epString passwordArray2 = 
  do
    let onePassword = read epString !! (n-1) :: Int;
    let temp = onePassword : passwordArray2;
    let passwordArray2 = temp;
    subForLoop (n-1) epString passwordArray2;


ask map=
    do
    putStr ("Select:"++"\n");
    putStr ("Find(find my password)"++"\n");
    putStr ("Show (show all password)"++"\n");
    putStr ("Store(save my password)"++"\n"++"Exit"++"\n");

    answer <- getLineFixed;
    let answer1 = to_upper answer;
    if(answer1 == "FIND");
        then
            find map;
        else if (answer1 == "SHOW");
            then
                showall map
        else if (answer1 == "STORE");
            then
                createAccount map;
        else if (answer1 == "EXIT");
            then
                putStr ("Thank you! Have a good day!");
            else
                putStr ("Invalid! please try again!");



showall map=
   do
   let allpasswords = M.toList map
   print (allpasswords)
   putStr ("Continue? (y/n)"++"\n")
   answer <- getLineFixed
   if (answer == "y")
            then
               ask map
            else if (answer == "n");
                    then
                        putStr ("Thank you! Have a good day!");

                    else
                        putStr ("Invalid! please try again!");
                        ask map

printMap []=
   do
   print (2)

printMap (h:t)=
   do
   print (h)
   printMap t


createAccount map=
    do
      putStr ("Please input the website: " )
      w <- getLineFixed
      putStr ("Please input your username: " )
      u <- getLineFixed
      putStr ("Please input your password: " )
      p <- getLineFixed

      if (M.member (w, u) map)
         then
           override (w, u, p) map
         else
           return()

      let ep = encode p
      let newmap = M.insert (w, u) ep map
      appendFile "password.txt" (w ++ " " ++ u ++ " " ++ show(ep) ++ "\n")
      putStr ("Successful！" )
      ask newmap


override (w, u, p) map =
  do
  putStr ("account already exists \n" ++ "override? (n/y)")
  a <- getLineFixed
  if (a == "n")
      then
       ask map
      else
       return()

  let ep = encode p
  let newmap = M.insert (w, u) ep map

  putStr ("Successful！ \n" )
  ask newmap




find map=
    do
    putStr ("The website? \n" )
    website <- getLineFixed
    putStr ("Your account name? \n" )
    account <- getLineFixed
    -- putStr ("Your information is: " ++"\n"++ website  ++"\n" ++  accountname ++"\n" ++ (load website accountname))
    let password = M.lookup (website, account) map

    if (password == Nothing)
      then
        print ("account does not exist! ")
       else
         print( decode (fromJust password))
    ask map
   
getLineFixed =
  do
    line <- getLine
    return (fixdel2 line)
    
fixdel2 :: [Char] -> [Char]
fixdel2 st = fst (remdel2 st)
-- remdel2 st   returns (resulting_string, number_of_deletes_to_do)
remdel2 :: [Char] -> ([Char], Int)
remdel2 [] = ([],0)
remdel2 ('\DEL':t) = (s,n+1)
  where (s,n) = remdel2 t
remdel2 (h:t)
  | n>0 = (s,n-1)
  | otherwise = (h:s,0)
  where (s,n) = remdel2 t

to_upper xs = [if (x==fst n) then snd n else x | x <- xs, n <- (zip ['a'..'z'] ['A'..'Z']), (x==fst n) || (x==snd n)]



-- TODO: empty for now, should load the file into the map
loadFile :: Map (String, String) [int]
loadFile = M.empty

go = main
