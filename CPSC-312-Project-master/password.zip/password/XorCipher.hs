module XorCipher where

import System.IO
import Control.Monad
import Data.Bits
import Data.Char (ord, chr)



load = do
    contents <- readFile "password.txt"
    putStrLn contents

store = do
    password <- getLine
    appendFile "password.txt" (password ++ "\n")



key = 672

encode :: Foldable t => t Char -> [Int]
encode plainText = foldr (\char lst -> (xor (ord char) key) : lst ) [] plainText

decode :: Foldable t => t Int -> [Char]
decode encodedText = foldr (\num lst -> (chr (xor num key)) : lst ) [] encodedText



